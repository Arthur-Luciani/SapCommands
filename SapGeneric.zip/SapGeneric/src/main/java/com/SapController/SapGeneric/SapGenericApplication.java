package com.SapController.SapGeneric;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SapGenericApplication {

	public static void main(String[] args) {
		SpringApplication.run(SapGenericApplication.class, args);
	}

}
