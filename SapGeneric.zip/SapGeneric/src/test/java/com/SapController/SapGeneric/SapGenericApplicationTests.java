package com.SapController.SapGeneric;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SapGenericApplicationTests {

	@Test
	void contextLoads() {
	}

}
